`timescale 1ns/1ps

module tb_processador;
  
  // Sinais de estímulo do sistema
  reg clk;
  reg rst;
  reg enable;
  reg [31:0] ULA_A, ULA_B;
  reg [31:0] IDEXmul;
  reg [2:0] IDEXfunct3;
  reg [4:0] IDEXrd;
  reg signed [31:0] signedS;
  reg unsigned [31:0] unsignedS;
  wire [63:0] tempS;
  wire [63:0] tempU;
  // Instanciação do módulo topo do seu processador
  MulPipelined32Bits uut (
    .Clk(clk),
    .Reset(rst),
    .A(ULA_A),
    .mul(IDEXmul),
    .funct3(IDEXfunct3[1:0]),
    .B(ULA_B),
    .Rd(IDEXrd),
    .counter(counter),
    .regularS(signedS),
    .unsignedS(unsignedS),
    .tempS(tempS),
    .tempU(tempU)
  );

  // Gerador de Clock (Período de 20ns -> 50 MHz)
  always #10 clk = ~clk;

  initial begin
    clk = 0;
    rst = 1;
    enable = 1;

    $dumpfile("sinais.vcd");   // nome do arquivo de saída
    $dumpvars(0, tb_processador); // 0 = captura TUDO recursivamente

    #40;
    rst = 0;
    
    // aqui você aplica suas instruções / estímulos
    #1000;
    $finish;
  end

  always @(posedge clk) begin
     if (!rst && enable) begin

    end
  end
endmodule