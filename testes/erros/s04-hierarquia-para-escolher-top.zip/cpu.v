module alu(input [3:0] a, input [3:0] b, output [3:0] y);
  assign y = a + b;
endmodule

module regfile(input clk, input [3:0] d, output reg [3:0] q);
  always @(posedge clk) q <= d;
endmodule

module cpu(input clk, input [3:0] a, input [3:0] b, output [3:0] q);
  wire [3:0] s;
  alu u_alu(.a(a), .b(b), .y(s));
  regfile u_rf(.clk(clk), .d(s), .q(q));
endmodule
