`timescale 1ns/1ps
module tb_cpu;
  reg clk = 0;
  reg [3:0] a = 1, b = 2;
  wire [3:0] q;
  cpu uut(.clk(clk), .a(a), .b(b), .q(q));
  always #5 clk = ~clk;
  initial begin
    $dumpfile("cpu.vcd");
    $dumpvars(0, tb_cpu);
    #20 a = 3; #20 b = 7; #20 $finish;
  end
endmodule
