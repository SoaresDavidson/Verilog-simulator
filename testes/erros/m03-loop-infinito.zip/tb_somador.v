`timescale 1ns/1ps
module tb_somador;
  reg clk = 0;
  reg [3:0] a = 0, b = 0;
  wire [4:0] s;
  somador dut (.a(a), .b(b), .s(s));
  always #1 clk = ~clk;
  always @(posedge clk) a <= a + 1;
  // sem $finish: a simulação nunca termina e estoura o tempo limite
endmodule
