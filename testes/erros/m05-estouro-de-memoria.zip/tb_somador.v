`timescale 1ns/1ps
module tb_somador;
  // 64M palavras de 32 bits: bem acima do limite de 512 MB do container
  reg [31:0] mem [0:67108863];
  integer i;
  initial begin
    for (i = 0; i < 67108864; i = i + 1) mem[i] = i;
    $finish;
  end
endmodule
