`timescale 1ns/1ps
module tb_somador;
  reg  [3:0] a, b;
  wire [4:0] s;
  somador dut (.a(a), .b(b), .s(s));
  integer i
  initial begin
    $dumpfile("somador.vcd");
    $dumpvars(0, tb_somador);
    for (i = 0; i < 16; i = i + 1) begin
      a = i; b = 15 - i; #10;
    end
    $display("fim da simulacao");
    $finish;
  end
endmodule
