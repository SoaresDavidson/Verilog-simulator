`timescale 1ns/1ps
module tb_somador;
  reg clk = 0;
  reg [3:0] a = 0, b = 0;
  wire [4:0] s;
  somador dut (.a(a), .b(b), .s(s));
  always #1 clk = ~clk;
  always @(posedge clk) begin a <= a + 1; b <= b + 3; end
  initial begin
    $dumpfile("somador.vcd");
    $dumpvars(0, tb_somador);
    #120000 $finish;  // ~120 mil instantes, acima do limite de 50 mil
  end
endmodule
