module top(input a, output y);
  modulo_que_nao_existe u0(.a(a), .y(y));
endmodule
