`timescale 1ns/1ps
// Somador de 4 bits: s = a + b, com vai-um em s[4].
module somador (
    input  wire [3:0] a,
    input  wire [3:0] b,
    output wire [4:0] s
);
  assign s = a + b;
endmodule
