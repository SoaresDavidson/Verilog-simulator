`timescale 1ns/1ps
module tb_somador;
  reg  [3:0] a, b;
  wire [4:0] s;

  somador dut (.a(a), .b(b), .s(s));

  initial begin
    $dumpfile("somador.vcd");
    $dumpvars(0, tb_somador);

    a = 0;  b = 0;  #10;
    a = 1;  b = 2;  #10;
    a = 5;  b = 3;  #10;
    a = 9;  b = 6;  #10;
    a = 15; b = 1;  #10;   // estoura 4 bits: s = 16
    a = 15; b = 15; #10;   // maior soma: s = 30

    $display("fim: a=%0d b=%0d s=%0d", a, b, s);
    $finish;
  end
endmodule
